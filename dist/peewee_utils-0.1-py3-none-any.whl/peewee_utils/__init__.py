from .main import prefetch_to_dict


__title__ = 'prefetch_to_dict'
__version__ = '0.1'
__author__ = 'Teguh Prabowo'
__license__ = 'MIT License'
__copyright__ = 'Copyright 2020 Teguh Prabowo'
